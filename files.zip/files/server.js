require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path = require("path");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// ---------- MongoDB ----------
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB connected"))
  .catch((err) => {
    console.error("MongoDB connection failed:", err.message);
    process.exit(1);
  });

const userSchema = new mongoose.Schema(
  {
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true },
  },
  { timestamps: true }
);
const User = mongoose.model("User", userSchema);

// ---------- Helpers ----------
// Only Gmail addresses are allowed (example: name@gmail.com)
const GMAIL_REGEX = /^[a-z0-9](?:[a-z0-9._+-]*[a-z0-9])?@gmail\.com$/i;
const isGmail = (email) => typeof email === "string" && GMAIL_REGEX.test(email.trim());

const signToken = (user) =>
  jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: "7d" });

const requireAuth = (req, res, next) => {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ message: "Please sign in." });
  try {
    req.userId = jwt.verify(token, process.env.JWT_SECRET).id;
    next();
  } catch {
    res.status(401).json({ message: "Your session has expired. Sign in again." });
  }
};

// ---------- API ----------
app.post("/api/register", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ message: "Enter an email and a password." });
    if (!isGmail(email))
      return res.status(400).json({ message: "Enter a valid Gmail address (name@gmail.com)." });
    if (password.length < 6)
      return res.status(400).json({ message: "Password must be at least 6 characters." });

    const exists = await User.findOne({ email: email.toLowerCase().trim() });
    if (exists)
      return res.status(409).json({ message: "An account with this email already exists." });

    // bcrypt: hash the password with 10 salt rounds before saving
    const hashed = await bcrypt.hash(password, 10);
    const user = await User.create({ email: email.toLowerCase().trim(), password: hashed });
    res.status(201).json({ token: signToken(user), email: user.email });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Something went wrong on the server." });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ message: "Enter your email and password." });
    if (!isGmail(email))
      return res.status(400).json({ message: "Enter a valid Gmail address (name@gmail.com)." });

    const user = await User.findOne({ email: email.toLowerCase().trim() });
    // bcrypt: compare typed password with the saved hash
    const ok = user && (await bcrypt.compare(password, user.password));
    if (!ok) return res.status(401).json({ message: "Email or password is incorrect." });

    res.json({ token: signToken(user), email: user.email });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Something went wrong on the server." });
  }
});

app.get("/api/me", requireAuth, async (req, res) => {
  const user = await User.findById(req.userId).select("-password");
  if (!user) return res.status(404).json({ message: "Account not found." });
  res.json({ email: user.email, createdAt: user.createdAt });
});

// ---------- Start ----------
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
