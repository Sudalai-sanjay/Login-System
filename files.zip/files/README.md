# Simple Login (Node + Express + MongoDB)

## Setup
1. Install Node.js (v18+) and MongoDB (local) — or use a free MongoDB Atlas connection string.
2. In this folder run:
   npm install
3. Copy `.env.example` to `.env` and set `MONGO_URI` and `JWT_SECRET`.
4. Start the server:
   npm start
5. Open http://localhost:3000

## API
- POST /api/register  { email, password } -> { token, email }
- POST /api/login     { email, password } -> { token, email }
- GET  /api/me        Authorization: Bearer <token> -> { email, createdAt }
